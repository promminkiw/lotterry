'use client';
import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { MdGridView, MdLocalActivity, MdChevronLeft, MdMenu } from 'react-icons/md';

interface SidebarProps { isOpen: boolean; onToggle: () => void; }

const navItems = [
  { href: '/dashboard', icon: MdGridView, label: 'แดชบอร์ด' },
  { href: '/draws', icon: MdLocalActivity, label: 'จัดการงวด' },
];

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onToggle }) => {
  const pathname = usePathname();
  const [isMobile, setIsMobile] = React.useState(false);

  React.useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const W = isOpen ? 220 : 60;

  return (
    <aside 
      className="sidebar" 
      style={{ 
        width: isMobile ? (isOpen ? '100%' : 60) : W,
        height: isMobile ? '100%' : 'auto',
        display: 'flex',
        flexDirection: 'column',
        transition: 'width 0.3s ease',
      }}
    >
      <div style={{ padding: isOpen ? '1.25rem 1.25rem 1.1rem' : '1.25rem 0 1.1rem', borderBottom: '1px solid rgba(255,255,255,0.06)', display: 'flex', alignItems: 'center', justifyContent: isOpen ? 'flex-start' : 'center', gap: '0.625rem', minHeight: 68 }}>
        <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: '0.625rem', textDecoration: 'none' }}>
          <div style={{ width: 34, height: 34, borderRadius: 'var(--r-md)', background: 'var(--gold)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, color: '#0d0f15', fontSize: 16, fontWeight: 700, fontFamily: 'var(--font-mono)', boxShadow: 'var(--shadow-gold)' }}>
            №
          </div>
          {isOpen && (
            <div>
              <div style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--base-50)', letterSpacing: '0.01em' }}>บันทึกหวย</div>
              <div style={{ fontSize: '0.6rem', color: 'var(--base-600)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', marginTop: 1 }}>LOTTERY MGR</div>
            </div>
          )}
        </Link>
      </div>

      <nav style={{ flex: 1, padding: isOpen ? '0.875rem 0.75rem' : '0.875rem 0.5rem', display: 'flex', flexDirection: 'column', gap: 2 }}>
        {navItems.map(({ href, icon: Icon, label }) => {
          const active = href === '/dashboard' ? pathname === '/dashboard' : pathname?.startsWith(href);
          return (
            <Link key={href} href={href} className={active ? 'nav-item-active' : ''} style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', padding: isOpen ? '0.5rem 0.75rem' : '0.5rem', justifyContent: isOpen ? 'flex-start' : 'center', borderRadius: 'var(--r-md)', textDecoration: 'none', color: active ? 'var(--gold)' : 'var(--base-400)', fontWeight: active ? 600 : 500, fontSize: '0.8125rem', transition: 'all 0.15s', border: active ? undefined : '1px solid transparent' }}
              onMouseEnter={e => { if (!active) { e.currentTarget.style.background = 'var(--base-800)'; e.currentTarget.style.color = 'var(--base-100)'; } }}
              onMouseLeave={e => { if (!active) { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'var(--base-400)'; } }}
            >
              <Icon size={17} style={{ flexShrink: 0 }} />
              {isOpen && <span style={{ whiteSpace: 'nowrap' }}>{label}</span>}
            </Link>
          );
        })}
      </nav>

      <div style={{ padding: '0.75rem', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
        <button onClick={onToggle} style={{ width: '100%', padding: '0.45rem', background: 'transparent', border: 'none', cursor: 'pointer', borderRadius: 'var(--r-md)', color: 'var(--base-500)', display: 'flex', alignItems: 'center', justifyContent: isOpen ? 'flex-start' : 'center', gap: '0.5rem', fontSize: '0.75rem', transition: 'all 0.15s' }}
          onMouseEnter={e => { e.currentTarget.style.background = 'var(--base-800)'; e.currentTarget.style.color = 'var(--base-200)'; }}
          onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'var(--base-500)'; }}
        >
          {isOpen ? <><MdChevronLeft size={16} /><span>ย่อเมนู</span></> : <MdMenu size={17} />}
        </button>
      </div>
    </aside>
  );
};