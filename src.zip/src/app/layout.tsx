'use client';
import React from 'react';
import './globals.css';
import { Sidebar } from '@/components/layout/Sidebar';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = React.useState(false); // Default closed on mobile
  const [isMobile, setIsMobile] = React.useState(false);

  React.useEffect(() => {
    // Check if mobile
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
      if (window.innerWidth >= 768) {
        setOpen(true);
      } else {
        setOpen(false);
      }
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  return (
    <html lang="th">
      <head>
        <meta charSet="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0" />
        <title>ระบบบันทึกหวย</title>
      </head>
      <body>
        <div style={{ display: 'flex', height: '100vh', background: 'var(--base-950)', flexDirection: isMobile && !open ? 'column' : 'row' }}>
          {/* Sidebar Overlay for Mobile */}
          {isMobile && open && (
            <div 
              onClick={() => setOpen(false)}
              style={{
                position: 'fixed',
                inset: 0,
                background: 'rgba(0,0,0,0.5)',
                zIndex: 39,
              }}
            />
          )}
          
          <div style={{ 
            position: isMobile && open ? 'fixed' : 'relative',
            left: 0,
            top: 0,
            height: isMobile && open ? '100vh' : 'auto',
            zIndex: 40,
            width: isMobile ? '100%' : 'auto',
          }}>
            <Sidebar isOpen={open} onToggle={() => setOpen(!open)} />
          </div>

          <main style={{ 
            flex: 1, 
            overflowY: 'auto', 
            background: 'var(--base-950)',
            width: isMobile && open ? 0 : '100%',
          }}>
            {children}
          </main>
        </div>
      </body>
    </html>
  );
}