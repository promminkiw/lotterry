'use client';

import React, { useState } from 'react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { Toast } from '@/components/ui/Toast';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';
import { DrawForm } from '@/components/forms/DrawForm';
import { DrawList } from '@/components/draws/DrawList';
import { CreateDrawInput } from '@/types';
import { drawService } from '@/services/drawService';
import { purchaseService } from '@/services/purchaseService';
import { useDraws } from '@/hooks/useData';
import {
  MdAdd as Plus,
  MdClose as Close,
  MdDelete as Trash2,
} from 'react-icons/md';

export default function DrawsPage() {
  const { draws, loading, refetch } = useDraws();
  const [showForm, setShowForm] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [deleteModal, setDeleteModal] = useState<{ drawId: string; name: string } | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleCreateDraw = async (input: CreateDrawInput) => {
    try {
      setIsSubmitting(true);
      await drawService.createDraw(input);
      setShowForm(false);
      setToast({ message: 'สร้างงวดใหม่สำเร็จ', type: 'success' });
      refetch(); // Refetch to get updated list
    } catch (error) {
      console.error('Error creating draw:', error);
      setToast({
        message: 'เกิดข้อผิดพลาดในการสร้างงวด',
        type: 'error',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteDraw = async (drawId: string) => {
    const draw = draws.find((d) => d.id === drawId);
    if (draw) {
      setDeleteModal({ drawId, name: draw.name });
    }
  };

  const confirmDelete = async () => {
    if (!deleteModal) return;

    try {
      setIsDeleting(true);
      await purchaseService.deleteAllPurchasesForDraw(deleteModal.drawId);
      await drawService.deleteDraw(deleteModal.drawId);
      setDeleteModal(null);
      setToast({ message: 'ลบงวดสำเร็จ', type: 'success' });
      refetch(); // Refetch to get updated list
    } catch (error) {
      console.error('Error deleting draw:', error);
      setToast({
        message: 'เกิดข้อผิดพลาดในการลบงวด',
        type: 'error',
      });
    } finally {
      setIsDeleting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="page">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="section-title">จัดการงวด</h1>
          <p className="section-subtitle">สร้างและจัดการงวดถ่ายทำใหม่</p>
        </div>
        <Button
          variant="primary"
          onClick={() => setShowForm(!showForm)}
          className="whitespace-nowrap flex items-center gap-2"
        >
          {showForm ? (
            <>
              <Close size={18} />
              ยกเลิก
            </>
          ) : (
            <>
              <Plus size={18} />
              สร้างงวดใหม่
            </>
          )}
        </Button>
      </div>

      {showForm && (
        <Card title="สร้างงวดใหม่" className="mb-8">
          <DrawForm onSubmit={handleCreateDraw} isLoading={isSubmitting} />
        </Card>
      )}

      <Card title={`จำนวนงวดทั้งหมด: ${draws.length}`}>
        <DrawList
          draws={draws}
          onDelete={handleDeleteDraw}
        />
      </Card>

      <Modal
        isOpen={deleteModal !== null}
        title="ยืนยันการลบงวด"
        confirmText="ลบเลย"
        isDangerous={true}
        isLoading={isDeleting}
        onClose={() => setDeleteModal(null)}
        onConfirm={confirmDelete}
      >
        <p className="text-dark-200 mb-3">
          คุณแน่ใจว่าต้องการลบงวด <strong className="text-dark-100">{deleteModal?.name}</strong> หรือไม่?
        </p>
        <p className="text-sm text-red-300 bg-red-900 bg-opacity-30 p-3 rounded-lg border border-red-700 flex items-start gap-2">
          <Trash2 size={16} className="flex-shrink-0 mt-0.5" />
          <span>ข้อมูลรายการซื้อและข้อมูลสรุปทั้งหมดของงวดนี้จะถูกลบออกไปด้วย</span>
        </p>
      </Modal>

      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  );
}
